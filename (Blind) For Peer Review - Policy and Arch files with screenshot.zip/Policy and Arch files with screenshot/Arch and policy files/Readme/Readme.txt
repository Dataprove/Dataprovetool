The CommonPolicy.pol here is incomplete, and covers the settings in the section 7 of the paper. 
There fore the tool DataProVe-v0.9.4-blind.pyc will return more violations regarding consent and purposes. 
However, in this case, it is interesting to look at the linkability and possession properties.