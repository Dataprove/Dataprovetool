We aim at solving the consent related "warnings" from the files in "(Blind) For Peer Review - Policy and Arch files with screenshot.zip", 
but we did not specify the Collection Purposes in the policy, therefore, we just ignore the related warnings in the results. 


###################################################################################################################################################################################
In the common policy we extend the followings:  

1. In the possession policy, we set that "Phone" can have "ephIDother"  
2. In transfer policy of "ephIDother" (from the perspective of sp) we add "backend" to the list of entity to whom "ephIDother" can be transfered. 
3. In the connection permit policy, we set that phone can link "ephIDother" and "ephIDbackend". (this is because in the arch. phone can compare the others 
ephIDs with the ones it receives from the "backend")


###################################################################################################################################################################################

In the "DP3T low cost" architecture, we added (DP3T - extended - 31 actions. Running time 14.854 sec (average after 10 consecutive runnings)): 

1. CALCULATEAT(phone,exposLevelown(ephIDother,ephIDbackend),Time(t))  # The exposure level of phone's owner is calculated based on comparing "ephIDother" and "ephIDbackend". 
2. RECEIVEAT(sp,Uconsent(ephIDother,backend),Time(t))   # This specifies the reception of the usage consent for "backend" to calculate/create/receive "ephIDother".   
3. RECEIVEAT(sp,Fwconsent(ephIDother,backend),Time(t))  # This specifies the reception of  the transfer consent for "backend" to receive "ephIDother". 

We removed 1 arch:
1. CALCULATEAT(phone,exposLevelown,Time(t)) as we replaced it with CALCULATEAT(phone,exposLevelown(ephIDother,ephIDbackend),Time(t)).

###################################################################################################################################################################################
In the "PEP-IMP" architecture, we added (PEP-IMP extended 47 arch - 24.251 sec average after 10 consecutive runnings): 

1. RECEIVEAT(sp,Uconsent(longID,mainstorage),Time(t))   # This specifies the reception of the usage consent for "mainstorage" of "sp" to calculate/create/receive "longID". 
2. RECEIVEAT(sp,Uconsent(longID,backend),Time(t))  # This specifies the reception of  the usage consent for "backend" to calculate/create "longID". 
3. RECEIVEAT(sp,Uconsent(ephIDown,mainstorage),Time(t))   # This specifies the reception of the usage consent for "mainstorage" of "sp" to calculate/create/receive "longID". 
4. RECEIVEAT(sp,Uconsent(ephIDown,phone),Time(t))   # This specifies the reception of the usage consent for "phone" to calculate/create/receive "ephIDown".
5. RECEIVEAT(sp,Uconsent(ephIDother,phone),Time(t))   # This specifies the reception of the usage consent for "phone" to calculate/create/receive "ephIDother".
6. RECEIVEAT(sp,Sconsent(ephIDown,mainstorage),Time(t)) # This specifies the reception of the storage consent for "mainstorage" to store "ephIDown".
7. RECEIVEAT(sp,Sconsent(exposLevelown,phone),Time(t)) # This specifies the reception of the storage consent for "phone" to store "exposLevelown".
8. RECEIVEAT(sp,Fwconsent(ephIDother,backend),Time(t)) # This specifies the reception of the transfer consent for "backend", to whom be "exposLevelown" can be transferred.

We ignore the warnings of the lack of CREATION/CALCULATION of "ephIDbackend", as "ephIDbackend"s are not created, but they  
only denotes the ephIDs sent by the backend to the phones (these are the ephIDs uploaded by other phones). 
  

