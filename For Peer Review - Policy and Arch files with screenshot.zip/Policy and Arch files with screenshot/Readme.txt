These files are intended for the reviewers in the peer review process. 

You can run the example Arch and policy files by openning CommonPolicy.pol and under "ARCHITECTURE-TEXTMODE", open the architecture file. 
Then, click on Save Content and run [[Verify]]