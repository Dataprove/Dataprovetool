Under Section "Examples with cryptographic functions" in the user manual.
  - Example 8/c (Collection policy, CREATE action in the architecture) 


