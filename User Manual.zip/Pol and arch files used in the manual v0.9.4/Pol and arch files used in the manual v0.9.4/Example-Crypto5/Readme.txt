Under Section "Examples with cryptographic functions" in the manual.
  - Example 5 (additional sub-component, panel). 
arch5a.arch => (5/a) case 1
arch5b.arch => (5/b) case 2

