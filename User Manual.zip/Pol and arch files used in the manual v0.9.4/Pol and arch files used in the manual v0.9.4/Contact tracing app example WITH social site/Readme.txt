These files are for the contact tracing app example at the beginning of the "Application Examples" section. 
In this version, a social media company (as main-component) is defined in the architecture from which the service provider can 
get the social profile that contains name and places where that person visited.  