Under Section "Examples with cryptographic functions" in the user manual.
  - Example 8/b (Collection policy, No consent collection in the architecture) => Violation of the DPR conformance


