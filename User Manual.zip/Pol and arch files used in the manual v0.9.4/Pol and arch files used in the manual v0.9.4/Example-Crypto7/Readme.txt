Under Section "Examples with cryptographic functions" in the user manual.
  - Example 7 (Nested Symmetric and asymmetric key encryption)


