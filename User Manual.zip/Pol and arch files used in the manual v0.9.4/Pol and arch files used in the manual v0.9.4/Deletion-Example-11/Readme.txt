Example 11 in the user manual v0.9.1.
Deletion sub-policy.