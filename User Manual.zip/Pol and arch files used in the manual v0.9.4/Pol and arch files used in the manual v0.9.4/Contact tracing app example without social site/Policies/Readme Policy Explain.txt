contacttracingPol.pol  => every sub-policy left blank/empty. 
contacttracingPolIdPlacePossessionAllowed.pol => sp is allowed/has the right to have "id" and "places".
contacttracingPolWithLinkForbidden.pol => sp is forbidden/does not have the right to link "id" and "places".  