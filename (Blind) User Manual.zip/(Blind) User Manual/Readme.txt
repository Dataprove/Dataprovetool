Blind version of the user manual with detailed GUI examples and TEXTMODE examples on compound data types.
The template files can be open and tested (both GUI and text mode versions).